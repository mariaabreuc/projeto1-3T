criaCartao(
    'conhecimento gerais',
    'De onde é a invenção do chuveiro elétrico?',
    'A invenção do chuveriro eletrico foi no brasil'
)

criaCartao(
    'Geografia',
    'Qual a capital da Italia?',
    'A capital da Italia é Roma'
)

criaCartao(
    'Matemática',
    'Quantas casas decimais tem o número pi?',
    'ela tem infinitas casas decimais '
)

criaCartao(
    'Lingua inglesa',
    'Como se diz socorro em Inglês?',
    'socorro em ingles é Help'
)